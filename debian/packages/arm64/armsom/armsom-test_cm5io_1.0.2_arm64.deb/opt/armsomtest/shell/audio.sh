#!/bin/bash

aplay -Dplughw:0,0 /opt/armsomtest/audio.wav