#!/bin/bash

cd /oem

sudo touch NV24.yuv